//ATENCIÓ!!! Per a ordenar el codi, vaig esborrar els comentaris anteriors, i només comentare en profunditat els nous passos fets.
//AQUESTA VERSIO TE UNA PETITA DIFERENCIA!ES VA ESBORRAR UNA LINIA DE CODI IMPORTANT per a reduir el array quan va duna partida amb mes cartes a una amb menys cartes. També he afegit un highlight blau a la pantalla de registre per a que es vegui quina ha set la ultima partida jugada
//variables que guarden el maxim de cartes amb que es pot jugar, el minim de cartes, i el maxim de puntuacions que es veuran al a pantalla de registre
const MAX_CARTES = 20;
const MIN_CARTES = 6;
const maximMostres = 5;

//el numero de cartes amb que volem començar a jugar
var NUM_CARTES = 6;
//tamany de les cartes
var AMPLE_CARTA = 0;
var ALT_CARTA = 0;
//per a saber quantes columnes fan falta
var numColumnes = 0;
//guarda el nombre d'intents
var intents = 0;
//guarda el temps limit per a fer la partida
let tempsLimit = 30;
//guarda el nivell en el que estem
var numPartida = 0;
//guarda en quin estat es troba la partida
var estatPartida = "Partida no iniciada";
//guarda el nombre de partides
var partides = 0;
//guarda si estem en game over o no
var gO = false;
//el temps que es mostra
var tempsFinal = 0;
//index per a moure for
var indexPuntuacio = 0;

//aquests arrays serveixen per a guardar tota la informació que surt a la pantalla de registre i les imatges de les cartes (img[])
var numIntents = [];
var numTemps = [];
var numEncerts = [];
var img = [];
var numNivells = [];
var numPartides = [];
//aquí es guarden les posicions de la x y la y de cada carta
var x = []; //
var y = []; //
//es guarda el valor corresponent a cada carta visible o no visible
var visibleOculta = [];
//guarda els valors associats a les cartes
var valorsCartes = [];
//aquestes variables son per a saber en qun punt de la tirada estem
var carta1 = -1;
var carta2 = -1;
var posicion1 = 0;
var posicion2 = 0;
var numCartes = 0;
var totalCartes = 0;
//si el joc ha acabat o no
var finalJuego = false;
//index per als for
let i = 0;
var j = 0;
//cuantes cartes hi ha dibuixades de moment
var cartesDibuixades = 0;
//la distancia de separacio entre cartes
var distanciaSeparacio = 0;
//un altre index per a fors
var index = 0;
// son les cartes iguals?
var iguals = "neutre";
//diferents posicions inicials depenent de quantes cartes ha de dibuixar
var posicioInicial = 0;
var posicioInicialY = 0;
var posicioInicialY2 = 0;

//temps que es guarda un cop cada partida per saber en quin punt de la compta hem començat la partida
var tempsInicial = 0;
//aqui es guarden els millisegons /1000, per a que ens doni segons
var temps = 0;
var puntuacio = 0;
//per a saber la dificultat del nivell
var nivell = "fàcil";
//per a guardar fonts
var myFont;
var myFontBold;
var myFontHand;


//aquí carreguem totes les fotos que volem fer servir, abans de que sinicii el joc
function preload() {

  //volia fer servir un for per a carregar les imatges, pero no se perquè no fucnionava, i ho he fet així.
  myFont = loadFont('assets/fonts/lithosProRegular.otf');
  myFontBold = loadFont('assets/fonts/LITHOSPRO-BLACK.OTF');
  myFontHand = loadFont('assets/fonts/SEGOESC.TTF');
  img[0] = loadImage("/assets/carta0.png");
  img[1] = loadImage("/assets/carta1.png");
  img[2] = loadImage("/assets/carta2.png");
  img[3] = loadImage("/assets/carta3.png");
  img[4] = loadImage("/assets/carta4.png");
  img[5] = loadImage("/assets/carta5.png");
  img[6] = loadImage("/assets/carta6.png");
  img[7] = loadImage("/assets/carta7.png");
  img[8] = loadImage("/assets/carta8.png");
  img[9] = loadImage("/assets/carta9.png");
  img[10] = loadImage("/assets/carta10.png");
}



function setup() {
  //aquesta funcio fa que el num de cartes es mantingui entre els marges 
  limitador();
  //per a tenir guardat el temps actual tota lestona
  tempsInicial = round(millis() / 1000);
  //sinicia a 1 el nombre de partides i el nombre del nivell
  numPartida = 1;
  partides = 1;
  indexPuntuacio = 1;
  //el canvas es relatiu a la finestra, y es crea al draw per a que si fem la finestra petita es redibuixi el canvas
  createCanvas(windowHeight * 0.75, windowHeight * 0.80);
  //inicio valors diversos
  distanciaSeparacio = width / 36;

  AMPLE_CARTA = width / 7.5;
  ALT_CARTA = AMPLE_CARTA * 1.5;


  //per a saber com dibuixar les columnes
  columnes();
  //per a posicionar les cartes
  posicionarCartas();
  //donar valor a les cartes
  iniciarValores();
  //no hih a cap carta apretada
  numCartes = 0;
  //frames a la que es refresca la pantalla
  frameRate(30);
}

function draw() {


  temps = round(millis() / 1000);
  distanciaSeparacio = width / 36;
  AMPLE_CARTA = width / 7.5;
  ALT_CARTA = AMPLE_CARTA * 1.5;
  posicionarCartas();
  //mentre el joc no acabi
  if (!finalJuego) {
    background(160, 200, 255);
    //dibuixa les cartes
    dibujarCartas();
    //aquí determinem quin nivell de dificultat correspont al nivell al que estem
    lvl();
    //aquest es el temps limit per resoldre cada partida
    tempsLimit = 30;
    //controla el temps i si sens acaba, es game over
    gameOver();
    //aquest if controla que s'escriu a la pantalla de registre a laprtat de temps
    if (!gO) {
      numTemps[indexPuntuacio] = tempsFinal;
    } else {

      numTemps[indexPuntuacio] = "fallat";
    }
    //invoco un objecte precreat
    var marcador = new Hud();
    marcador.display();
    //condició de victoria
    if (totalCartes == NUM_CARTES / 2) {
      finalJuego = true;
      estatPartida = "Partida finalitzada";
      //aqui evaluem si les cartes son iguals
    } else if (numCartes == 2) {
      cartasIguales();
    }
  }
  //aquest if dibuixen pantalla de registre quan toca.
  if (finalJuego && estatPartida == "Pantalla de registre") {

    let registre = new Puntuacions();
    registre.display();

  }
  if (finalJuego && estatPartida == "Partida finalitzada") {

    registre = new Puntuacions();
    registre.win();

  }
  print(estatPartida);

}



function posicionarCartas() {
  //per a saber cuantes columnes hi haura
  columnes();
  //depenent d'aixo, les comença a dibuixar en un punt o un altre  
  if (numFiles == 4) {

    posicioInicialY = height * 0.8;
    posicioInicialY2 = ALT_CARTA / 2 + distanciaSeparacio;

  }

  if (numFiles == 3) {
    posicioInicialY = height * 0.7;
    posicioInicialY2 = ALT_CARTA + distanciaSeparacio;
  }
  //aquest for assigna valors de posicio a totes les cartes 
  for (i = posicioInicial; i < width && cartesDibuixades <= NUM_CARTES - 1; i = i + AMPLE_CARTA + distanciaSeparacio) {
    for (j = posicioInicialY2; j < posicioInicialY && cartesDibuixades <= NUM_CARTES - 1; j = j + ALT_CARTA + distanciaSeparacio) {

      if (index <= NUM_CARTES - 1) {

        x[index] = i;
        y[index] = j;
        index = index + 1;

      }

      cartesDibuixades = cartesDibuixades + 1;

    }
  }

  cartesDibuixades = 0;
  index = 0;


}

function iniciarValores() {
  //aquesta funció otorga valors a les cartes
  limitador();

  for (i = 0; i < NUM_CARTES; i = i + 1) {
    if (i <= NUM_CARTES / 2) {

      valorsCartes[i] = i + 1;
    }

    if (i > NUM_CARTES / 2 - 1) {

      valorsCartes[i] = i + 1 - NUM_CARTES / 2;
    }

    visibleOculta[i] = "oculta";
  }

  //valors aleatoris de les cartes
  valorsCartes = shuffle(valorsCartes);
}

function dibujarCartas() {

  //aquesta funcio invoca objectes precreats i els dibuixa en pantalla, depenent de si la carta esta oculta o no.

  for (i = 0; i <= NUM_CARTES - 1; i = i + 1) {
    var cartes = new Carta();
    cartes.display();
  }


  for (i = 0; i < NUM_CARTES; i = i + 1) {

    if (visibleOculta[i] == "oculta") {
      var cartesTapades = new Carta();
      cartesTapades.display2();
    }
  }
}

function cartasIguales() {
  //quan tenim dos cartes clicades, les compara
  if (carta1 == carta2 && (carta1 > 0 && carta2 > 0)) {
    totalCartes = totalCartes + 1;
    iguals = "iguals";
    intents = intents + 1;
    //un cop comprobat si son iguals, torna a posar el numCartes a 0, per a poder fer una altra tirada
    numCartes = 0;
  }

  if (carta1 != carta2 && (carta1 > 0 && carta2 > 0)) {
    frameRate(1);
    iguals = "diferents";
    intents = intents + 1;
    numCartes = 0;
    visibleOculta[posicio1] = "oculta";
    visibleOculta[posicio2] = "oculta";
  }


}

function mousePressed() {
  //cada vegada que apretem el mouse, depenent de quin estat estem, passa al següent o no. També controla el frameRate.

  if (totalCartes == NUM_CARTES / 2) {
    //aquesta linia de codi fa que es visualitzi el temps que hem emprat, enlloc del temps que ens faltava per acabar
    numTemps[indexPuntuacio] = tempsRestat;
  }

  if (finalJuego && estatPartida == "Pantalla de registre") {
    recomençar();
    gO = false;
  }
  if (finalJuego && estatPartida == "Partida finalitzada") {

    estatPartida = "Pantalla de registre";
  }

  if (numCartes == 0) {
    frameRate(30);
  }

  if (estatPartida == "Partida no iniciada" || estatPartida == "Partida iniciada") {
    queCarta(x, y);
  }
  if (!finalJuego && estatPartida == "Pantalla de registre") {

    estatPartida = "Partida no iniciada";

  }
  //quan cliquem, si el joc ha acabat, aprofita per guardar les puntiuacions que surtiran al registre. Ho faig aquí per a no estar tot el rato assignan el mateix valor al array. No guardo el temps aquí perquè sino no es guarda com toca... ho poso al draw per a que s'actualitzi cada segon com a minim.
  if (!gO) {
    numEncerts[indexPuntuacio] = totalCartes;
    numIntents[indexPuntuacio] = intents;

  } else {
    numEncerts[indexPuntuacio] = "fallat";
    numIntents[indexPuntuacio] = "fallat";
  }
  numPartides[indexPuntuacio] = partides;
  numNivells[indexPuntuacio] = numPartida;
}

function recomençar() {
  //aquesta funció reinicia el joc d'una manera o una altra, depenent del resultat de la partida anterior (si es gameOver, reinicia nivell, si ens passem nivell passa al seguent, i si ens passem el joc torna al principi
  if (!gO) {

    if (NUM_CARTES < MAX_CARTES) {
      intents = 0;
      numCartes = 0;
      totalCartes = 0;
      NUM_CARTES = NUM_CARTES + 2;
      iniciarValores();
      posicionarCartas();
      tempsInicial = round(millis() / 1000);
      finalJuego = false;
      numPartida = numPartida + 1;
      partides = partides + 1;
    } else if (NUM_CARTES == MAX_CARTES) {
      intents = 0;
      numCartes = 0;
      totalCartes = 0;
      NUM_CARTES = MIN_CARTES;
      //aquesta línia es molt important. Sense aquesta línia el joc es bugueja. Si anem d'una partida on el numero de cartes era mes gran que el de la partida actual, i no esborrem el array on es guarden els valors (normalment el sobreescribim, pero al passar de mes cartes a menys, queden nombres que no es sobreescriuen. Es per això que si es vol tornar a reiniciar el joc, sha de fer un splice. Faig servir el splice, perque el slice no canvia el array original. Començo a 0 perquè vull esborrar tot el array. 

      valorsCartes.splice(0, MAX_CARTES);
      iniciarValores();
      posicionarCartas();
      tempsInicial = round(millis() / 1000);
      finalJuego = false;
      numPartida = 1;
      partides = partides + 1;


    }
  } else {


    intents = 0;
    numCartes = 0;
    totalCartes = 0;
    iniciarValores();
    posicionarCartas();
    tempsInicial = round(millis() / 1000);
    finalJuego = false;
    partides = partides + 1;

  }
  //faig avançar el index i si es més gran del nombre maxim de puntuacions que han dapareixer en pantalla.
  //reinicio el index

  indexPuntuacio = indexPuntuacio + 1;
  if (indexPuntuacio > maximMostres) {
    indexPuntuacio = 1;
  }
}

function columnes() {
  //aquesta funcio controla el nombre de cartes que hi ha i com les coloca al canvas depenent si son multiples de 3 o no.
  if (NUM_CARTES % 3 == 0) {
    numFiles = 3;
    numColumnes = NUM_CARTES / 3;
  }

  if (NUM_CARTES % 2 == 0 && NUM_CARTES % 3 != 0) {
    numFiles = 4;
    numColumnes = NUM_CARTES / 4;
  }
  //el numero de columnes es determina pel nombre de files i el nombre de cartes en joc
  numColumnes = round(NUM_CARTES / numFiles);

  if (numColumnes == 2) {

    posicioInicial = width / 2 - AMPLE_CARTA / 2 - distanciaSeparacio / 2;

  }
  if (numColumnes == 3) {

    posicioInicial = width / 2 - AMPLE_CARTA - distanciaSeparacio;

  }
  if (numColumnes == 4) {

    posicioInicial = width / 2 - AMPLE_CARTA * 2 + distanciaSeparacio;
  }
  if (numColumnes == 5) {

    posicioInicial = AMPLE_CARTA + distanciaSeparacio * 1.5;
  }
  if (numColumnes == 6) {

    posicioInicial = AMPLE_CARTA / 2 + distanciaSeparacio;
  }
}

function windowResized() {
  //això canvia el tamany de la finestra
  if (windowHeight <= windowWidth) {
    resizeCanvas(windowHeight * 0.75, windowHeight * 0.8);

  } else {
    resizeCanvas(windowWidth * 0.75, windowWidth * 0.8);
  }
}

function queCarta(posX, posY) {
  //aquesta funcio controla quines cartes tenim apretades, i canvia el estat de visibleOculta de cada carta com convé.
  for (i = 0; i <= NUM_CARTES; i = i + 1) {

    if (mouseX < posX[i] + AMPLE_CARTA / 2 && mouseX > posX[i] - AMPLE_CARTA / 2 && mouseY < posY[i] + ALT_CARTA / 2 && mouseY > posY[i] - ALT_CARTA / 2) {
      //si clicquem sobre una carta que esta oculta i no tenim cap carta clicada a la jugada  
      if (visibleOculta[i] == "oculta" && numCartes == 0) {
        visibleOculta[i] = "visible";
        numCartes = numCartes + 1;
        carta1 = valorsCartes[i];
        posicio1 = i;
        //cada vegada que s'apreta una carta i la partida encara no esta iniciada, s'inicia la partida
        if (estatPartida == "Partida no iniciada") {
          estatPartida = "Partida iniciada";
        }

      }
      //si clicquem una carta que esta oculta, i ja tenim una carta triada
      if (visibleOculta[i] == "oculta" && numCartes == 1) {
        visibleOculta[i] = "visible";
        numCartes = numCartes + 1;
        carta2 = valorsCartes[i];
        posicio2 = i;
      }
    }

  }

}

function lvl() {
  //aquesta funcio habia de servir per a otorgar punts depenent de la dificultat del nivell. Al final no l'he feta servir perquè amb els punts quedava la pantalla massa plena, però no l'he tret perquè em serveix per a visualitzar el nivell de dificultat de cada nivell, que es divertit
  if (NUM_CARTES <= MAX_CARTES / 3) {
    nivell = "Fàcil"

  }


  if (NUM_CARTES > MAX_CARTES / 3 && NUM_CARTES <= (MAX_CARTES / 3) * 2) {
    nivell = "Mitja";


  }

  if (NUM_CARTES > (MAX_CARTES / 3) * 2 && NUM_CARTES <= MAX_CARTES) {
    nivell = "Difícil";

  }

}

class Carta {
  //aquesta classe em serveix com a plantilla per als objectes carta. Guarda la posicio x i y, el tamany de les cartes, i les imatges associades
  //amb el construcor puc preassignar valors i despres accedir-hi. simplement col.loco els atributs del objecte com el text, linia, tamany.. etc a cada objecte i despres crido al còdi la part que interessa.
  constructor(pX, pY, ampleCarta, altCarta, imag) {
    this.pX = x[i];
    this.pY = y[i];
    this.ampleCarta = AMPLE_CARTA;
    this.altCarta = ALT_CARTA;
    this.imag = img[valorsCartes[i]];
    //faig servir una funcio per a crear les cartes .
    //he creat com a minim una funcio display a dins de cada objecte(classe) per a tal de poder controlar que es visualitzarà amb els parametres del objecte. No he posat parametres per a tot el que apareix al display perquè he anat fent sobre la marxa el disseny, per poder anar modificant amb agilitat.
    this.display = function() {
      textSize(width / 20);
      textAlign(CENTER, CENTER);
      textFont(myFont);
      fill(155, 100, 255);
      stroke(255, 155, 0);
      strokeWeight(width / 60);
      fill(60);
      noStroke();
      strokeWeight(width / 60);
      fill(255, 155, 0);
      //faig servir el this perque soc dins de la classe, si vulgues recuperar el pX a fora d'aquesta funció(al draw per exemple) faria servir Carta.pX enlloc de this.pX
      text(valorsCartes[i], this.pX, this.pY);
      //la imagte es dibuixa desde el centre
      imageMode(CENTER);
      image(this.imag, this.pX, this.pY, this.ampleCarta, this.altCarta);
    }
    //el revers de la carta. 
    this.display2 = function() {
      fill(60);
      strokeWeight(width / 60);
      fill(155, 100, 255);
      noStroke();
      fill(255, 155, 0);
      imageMode(CENTER);
      image(img[0], this.pX, this.pY, this.ampleCarta, this.altCarta);

    }
  }
}
//aquesta classe guarda el HUD
class Hud {
  //tan al hud com a la pantalla de registre, nomes necesito guardar la x i la y per agilitzar el proces.
  constructor(pX, pY) {
    this.pX = width / 2;
    this.pY = height * 0.96;
    this.display = function() {
      textFont(myFont);
      fill("black");
      textSize(width / 30);
      text("Time: " + tempsLimit, this.pX / 3, this.pY / 1.05);
      text("Level: " + numPartida, this.pX, this.pY / 1.05);
      text("Difficulty : " + nivell, this.pX * 1.65, this.pY / 1.05);

      text("Partida: " + partides, this.pX / 3, this.pY);
      text("Intents: " + intents, this.pX, this.pY);
      text("Encerts: " + totalCartes, this.pX * 1.65, this.pY);
      //això ho he fet per a que es vegui mes clar que s'acaba el temps, apareixerà sobreimpres al mig de la pantalla el compte enrere en vermell ben gran.     
      if (tempsLimit < 4) {
        fill("crimson");
        textSize(width / 5);
        text(tempsLimit, width / 2, height / 2);
        fill("black");
      }

    }
  }
}

//aquesta classe guarda la pantalla de registre
class Puntuacions {
  constructor(pX, pY) {
    this.pX = width / 10;
    this.pY = height * 0.20;
    this.display = function() {
      textFont(myFontBold);
      background(220);
      fill("black");
      textSize(width / 20);
      text("Pantalla de registre", width / 2, this.pY * 0.4);
      textSize(width / 30);
      textFont(myFont);
      text("Partida", this.pX, this.pY * 0.9);
      text("Nivell", this.pX * 3, this.pY * 0.9);
      text("Intents", this.pX * 5, this.pY * 0.9);
      text("Encerts", this.pX * 7, this.pY * 0.9);
      text("Temps", this.pX * 9, this.pY * 0.9);
      textFont(myFont);
      //interficie d'usuari, per aveure punts i nivell de dificultat
      for (i = 1; i <= maximMostres; i++) {
        textFont(myFontHand);
        //aquest for fa que es creï el array on es guarden les puntuacions, encerts... que apareixeran al a pantalla de registre. Com esta limitat a un maxim de 5, he creat un index per tal de controlar que empleni el array 5 vegades. Per aixo el for fa 5 passades (indexPuntuacio s'inicialitza a 1 mes a dalt). cada vegada que reiniciem el joc, l'index augmenta  en 1, per lo que d'alguna manera es un pseudo for, que fa una pasada cada cop que reiniciem el joc, que es quan s'han de mostrar les puntuacions. D'aquesta manera ens asegurem que sempre guardem les 5 ultimes jugades. 
        //faig servir el condicional aquest, per tal d'evitar que intenti posar valors que encara no existeixen. D'aquesta manera, la primera vegada que intenta emplenar l'array, com numNivells es un número que només avança quan ens passem un nivell, el que fem es comprovar si en l'array d'aquesta informacio hi ha alguna cosa o no. Si no hi és, ja ni intenta fer la passada 
        if (numNivells[i] != undefined) {
          //aquest if fa que es posi de color la línia de l'ultim input de la pantalla de registre.
          if (i == indexPuntuacio) {
            fill("blue");

          } else {
            fill("black");
          }
          text(numPartides[i], this.pX, this.pY + i * height * 0.05);
          text(numNivells[i], this.pX * 3, this.pY + i * height * 0.05);
          text(numIntents[i], this.pX * 5, this.pY + i * height * 0.05);
          text(numEncerts[i], this.pX * 7, this.pY + i * height * 0.05);
          text(numTemps[i], this.pX * 9, this.pY + i * height * 0.05);
        }
      }
    }
    this.win = function() {
      //depenent de si guanyem o perdem, aquesta funció fa que aparegui una cosa o una altra en pantalla  
      if (!gO) {
        if (NUM_CARTES == MAX_CARTES) {
          background(220);
          textSize(width / 20);
          textFont(myFontBold);
          text("Congratulations!", width / 2, width * 0.4);
          textFont(myFont);
          text("You've completed all the game.", width / 2, width * 0.48);
          textSize(width / 25);
          textFont(myFontHand);
          text("Click to restart the game.", width / 2, width * 0.56);
        } else {
          background(220);
          textSize(width / 20);
          textFont(myFontBold);
          text("Level complete!", width / 2, width / 2);
          textSize(width / 25);
          textFont(myFontHand);
          text("Click to go next level", width / 2, width * 0.6);

        }
      } else {
        background(220);
        textSize(width / 20);
        textFont(myFontBold);
        text("Time's up. You have lost!.", width / 2, width / 2);
        textSize(width / 25);
        textFont(myFontHand);
        text("Click to restart level.", width / 2, width * 0.6);
      }
    }
  }
}
//funcio que controla el temps i si hem perdut per culpa del temps
function gameOver() {
  if (tempsLimit >= 0 && !finalJuego) {
    tempsLimit = tempsLimit - (temps - tempsInicial);
    tempsRestat = 30 - tempsLimit;
  }


  if (tempsLimit < 0) {
    tempsLimit = 0;
    gO = true;
    finalJuego = true;
    tempsRestat = 30;
    estatPartida = "Partida finalitzada";
  }
}
//funció per evitar números que buguejen el programa (nombres imparells, nombres majors al limit de cartes...)
function limitador() {

  if (NUM_CARTES % 2 > 0) {
    NUM_CARTES = NUM_CARTES + 1;
  }
  if (NUM_CARTES > MAX_CARTES) {
    NUM_CARTES = MAX_CARTES;
  }
  if (NUM_CARTES < MIN_CARTES) {
    NUM_CARTES = MIN_CARTES;
  }

}